# EcoGuard – Pollution Control System (UI/UX Portfolio Project)

**Tagline:** Breathe. Monitor. Act.

A responsive front-end demonstration based on the EcoGuard UI/UX internship report. It presents an air-quality dashboard, sample pollutant cards, health guidance, alerts, and a demo pollution-report form.

## Features
- Responsive layout for desktop and mobile
- AQI overview using clearly labelled illustrative sample data
- Clickable pollutant cards with details
- Monitoring-zone illustration
- Sample alerts and health advisory
- Pollution-report form with client-side demo confirmation
- Semantic HTML, accessible labels, focus states, and meta description

## Built with
- HTML5
- CSS3
- Vanilla JavaScript
- Google Fonts (internet connection needed for font loading)

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a browser.
3. No build tools or package installation are required.

## Publish with GitHub Pages
1. Create a GitHub repository named `ecoguard-pollution-control`.
2. Upload `index.html`, `styles.css`, `script.js`, and this `README.md` (the `assets` folder can remain empty or be removed).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site; the URL will appear on the Pages settings screen.

## Important note
This is a portfolio prototype, not a production pollution-monitoring service. AQI and pollutant values are sample data. The location control is a demo interaction, and report submissions are not transmitted or stored. Do not present the sample readings as live environmental data.

## Suggested repository description
Responsive EcoGuard pollution-monitoring UI/UX prototype built with HTML, CSS, and JavaScript.
