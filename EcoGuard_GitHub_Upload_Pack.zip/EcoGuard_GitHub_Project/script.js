const detailPanel = document.getElementById('detailPanel');

document.querySelectorAll('.pollutant-card').forEach((card) => {
  card.addEventListener('click', () => {
    const { name, value, unit, info } = card.dataset;
    detailPanel.innerHTML = `
      <span class="detail-symbol">i</span>
      <div><strong>${name} · Sample reading: ${value} ${unit}</strong>
      <p>${info} This value is illustrative and is not a live sensor measurement.</p></div>`;
    document.querySelectorAll('.pollutant-card').forEach((item) => item.setAttribute('aria-pressed', 'false'));
    card.setAttribute('aria-pressed', 'true');
  });
});

document.getElementById('locationBtn').addEventListener('click', () => {
  const button = document.getElementById('locationBtn');
  button.textContent = '⌖ Demo location selected';
  window.setTimeout(() => { button.textContent = '⌖ My location'; }, 2200);
});

document.getElementById('reportForm').addEventListener('submit', (event) => {
  event.preventDefault();
  const category = document.getElementById('category').value;
  const area = document.getElementById('area').value.trim();
  const id = `EG-DEMO-${Math.floor(1000 + Math.random() * 9000)}`;
  document.getElementById('formMessage').textContent =
    `Demo only: ${category} report for "${area}" prepared successfully. Reference: ${id}. No data was sent.`;
  event.target.reset();
});
